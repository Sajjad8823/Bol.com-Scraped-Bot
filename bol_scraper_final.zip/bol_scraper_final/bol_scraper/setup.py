# setup.py
from setuptools import setup, find_packages

setup(
    name='bol_scraper',
    version='1.0',
    packages=find_packages(),
)