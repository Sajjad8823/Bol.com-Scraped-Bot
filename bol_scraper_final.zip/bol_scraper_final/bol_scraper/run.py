import logging
import sys
import os
import traceback

# Force immediate output
sys.stdout.reconfigure(line_buffering=True)

print("="*60)
print("DEBUG: Script starting...")
print(f"Python version: {sys.version}")
print(f"Working directory: {os.getcwd()}")
print("="*60)

try:
    # Add src folder to Python path
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
    print(f"Python path: {sys.path}")
    
    # Test imports
    print("Importing scraper...")
    from scraper import BolScraper
    print("✓ Scraper imported successfully")
    
    # Setup logging
    logging.basicConfig(
        level=logging.DEBUG,  # Changed to DEBUG for more info
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )
    print("✓ Logging configured")
    
except Exception as e:
    print(f"✗ IMPORT ERROR: {e}")
    traceback.print_exc()
    input("Press Enter to exit...")
    sys.exit(1)

def main():
    print("\n" + "="*60)
    print("MAIN FUNCTION STARTING")
    print("="*60)
    
    search_terms = ["hitster",]
    
    # PROXY CONFIGURATION
    USE_PROXY = True
    
    # Format: http://username:password@host:port
    PROXY_URL = "http://user-JFw0HVWJnzleTJdX-type-residential-session-defryf4b-country-NL-city-Amsterdam-rotation-0:LGiu2jvkBmGy3sTP@geo.g-w.info:10080"
    
    print(f"Search terms: {search_terms}")
    print(f"Proxy enabled: {USE_PROXY}")
    print(f"Proxy URL (masked): {PROXY_URL.split('@')[-1] if '@' in PROXY_URL else PROXY_URL}")
    
    try:
        print("\nCreating scraper instance...")
        scraper = BolScraper(
            search_terms=search_terms,
            max_pages=1,
            headless=False,
            proxy=PROXY_URL if USE_PROXY else None,
            skip_duplicates=True
        )
        print("✓ Scraper created")
        
        print("\nStarting scraper...")
        scraper.start()
        print("✓ Scraper finished")
        
    except Exception as e:
        print(f"\n✗ SCRAPER ERROR: {e}")
        traceback.print_exc()
        input("Press Enter to exit...")
        raise

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\nFATAL ERROR: {e}")
        traceback.print_exc()
        input("Press Enter to exit...")