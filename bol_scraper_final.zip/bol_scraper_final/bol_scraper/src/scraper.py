import logging
import time
import random
import re
from urllib.parse import quote
from datetime import datetime
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException

from browser import SimpleBrowser
from database import SimpleDatabase

logger = logging.getLogger(__name__)


class BolScraper:
    # MODIFIED: Added proxy parameter
    def __init__(self, search_terms, max_pages=1, headless=False, proxy=None, skip_duplicates=True):
        self.search_terms = search_terms
        self.max_pages = max_pages
        self.headless = headless
        self.proxy = proxy  # ADDED
        self.skip_duplicates = skip_duplicates  # ADDED
        self.browser = SimpleBrowser(headless=headless, proxy=proxy)  # MODIFIED: pass proxy
        self.database = SimpleDatabase()
        self.run_id = None
        self.items_scraped = 0
        self.skipped_count = 0  # ADDED: track skipped duplicates
        
        self.xpaths = {
            'title': '//*[@id="mainContent"]/div/div[4]/div[2]/div/div[1]/h1/span',
            'price': '//*[@id="buyBlockSlot"]/div[1]/div/span/span[2]',
            'availability': '//*[@id="buyBlockSlot"]/div[2]',
            'seller_brand': '//*[@id="mainContent"]/div/div[4]/div[2]/div/div[2]/span[1]/p',
            'rating_button': '//*[@id="mainContent"]/div/div[4]/div[2]/div/div[2]/span[3]/p/button',
        }
        
    def start(self):
        logger.info("="*50)
        logger.info("Starting Bol.com Scraper")
        if self.proxy:
            logger.info(f"Using proxy: {self.proxy}")  # ADDED
        if self.skip_duplicates:
            logger.info("Duplicate checking: ENABLED")  # ADDED
        logger.info("="*50)
        
        self.run_id = self.database.log_run_start()
        
        try:
            self.browser.start()
            
            for term in self.search_terms:
                self.scrape_search_term(term)
                time.sleep(random.uniform(5, 10))
            
            # MODIFIED: Log both scraped and skipped
            logger.info(f"Finished! New items: {self.items_scraped}, Skipped duplicates: {self.skipped_count}")
            self.database.log_run_end(self.run_id, self.items_scraped, 'completed')
            
        except Exception as e:
            logger.error(f"Error: {e}")
            self.database.log_run_end(self.run_id, self.items_scraped, 'failed')
            raise
        finally:
            self.browser.close()
    
    def scrape_search_term(self, term):
        logger.info(f"\n--- Searching: {term} ---")
        
        encoded = quote(term)
        base_url = f"https://www.bol.com/nl/s/?searchtext={encoded}"
        
        # FIXED: Use max_pages parameter correctly
        for page_num in range(1, self.max_pages + 1):
            if page_num == 1:
                page_url = base_url
            else:
                offset = (page_num - 1) * 24
                page_url = f"{base_url}&offset={offset}"
            
            logger.info(f"Page {page_num}/{self.max_pages}: {page_url}")  # MODIFIED: show max_pages
            
            if not self.browser.open_page(page_url):
                continue
            
            time.sleep(3)
            self.browser.scroll_down()
            
            links = self._get_product_links()
            
            if not links:
                logger.warning("No products found")
                continue
            
            logger.info(f"Found {len(links)} products")
            
            for i, link in enumerate(links):
                logger.info(f"\n{'='*50}")
                logger.info(f"Product {i+1}/{len(links)}")
                
                # ADDED: Check for duplicate before scraping
                product_id = self._extract_id(link)
                if self.skip_duplicates and self.database.product_exists(product_id):
                    logger.info(f"SKIP: Product {product_id} already in database")
                    self.skipped_count += 1
                    continue
                
                self.scrape_product_page(link, term)
                time.sleep(random.uniform(3, 7))
            
            time.sleep(random.uniform(5, 8))
    
    def _get_product_links(self):
        links = []
        try:
            strategies = [
                "//a[contains(@href, '/nl/nl/p/')][not(contains(@href, 'javascript'))]",
                "a[href*='/nl/nl/p/']"
            ]
            
            for strategy in strategies:
                try:
                    if strategy.startswith("//"):
                        elements = self.browser.driver.find_elements(By.XPATH, strategy)
                    else:
                        elements = self.browser.driver.find_elements(By.CSS_SELECTOR, strategy)
                    
                    if elements:
                        for elem in elements:
                            href = elem.get_attribute('href')
                            if href and '/nl/nl/p/' in href and 'javascript' not in href:
                                clean_url = href.split('?')[0]
                                if clean_url not in links:
                                    links.append(clean_url)
                        
                        if links:
                            break
                except:
                    continue
            
            return links[:10]
            
        except Exception as e:
            logger.error(f"Error finding products: {e}")
            return []
    
    def scrape_product_page(self, url, search_term):
        try:
            if not self.browser.open_page(url):
                return
            
            logger.info(f"URL: {url[50:]}...")
            time.sleep(4)
            
            # Extract all data
            data = {
                'id': self._extract_id(url),
                'url': url,
                'search_term': search_term,
                'title': self._get_text_by_xpath(self.xpaths['title']),
                'price': self._extract_price_ultra_robust(),
                'availability': self._clean_availability(self._get_text_by_xpath(self.xpaths['availability'])),
                'seller_brand': self._extract_brand_simple(),
                'rating': self._extract_rating_simple(),
                'review_count': self._extract_review_count_simple(),
                'review_text': self._extract_review_text(),
                'category': self._extract_category_robust(),
                'image_url': self._extract_image_simple(),
                'currency': 'EUR',
                'sponsor_preference': self._extract_sponsor_robust(),
                'description_specification': self._extract_description(),
                'seller_and_rating': self._extract_seller_rating_robust(),
                'specification': self._extract_specification(),
            }
            
            # Log results
            logger.info(f"RESULTS:")
            logger.info(f"  Title: {data['title'][:50] if data['title'] else 'NOT FOUND'}...")
            logger.info(f"  Price: €{data['price']:.2f}" if data['price'] > 0 else "  Price: NOT FOUND")
            logger.info(f"  Category: {data['category'][:100]}..." if data['category'] else "  Category: NOT FOUND")
            logger.info(f"  Rating: {data['rating']}/5" if data['rating'] > 0 else "  Rating: NOT FOUND")
            logger.info(f"  Reviews: {data['review_count']}" if data['review_count'] > 0 else "  Reviews: 0")
            logger.info(f"  Brand: {data['seller_brand']}")
            logger.info(f"  Sponsor/Preference: {data['sponsor_preference']}" if data['sponsor_preference'] else "  Sponsor/Preference: NOT FOUND")
            logger.info(f"  Seller & Rating: {data['seller_and_rating'][:100]}..." if data['seller_and_rating'] else "  Seller & Rating: NOT FOUND")
            logger.info(f"  Specification: {data['specification']}" if data['specification'] else "  Specification: NOT FOUND")
            logger.info(f"  Availability: {data['availability'][:50]}...")
            
            if self.database.save_product(data):
                self.items_scraped += 1
                logger.info(f"  ✓ Saved #{self.items_scraped}")
            
        except Exception as e:
            logger.error(f"Error scraping: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    def _extract_id(self, url):
        match = re.search(r'/nl/nl/p/[^/]+/(\d+)', url)
        return match.group(1) if match else url[-20:]
    
    def _get_text_by_xpath(self, xpath):
        try:
            element = self.browser.driver.find_element(By.XPATH, xpath)
            if element:
                return element.text.strip()
        except:
            return None

    def _extract_category_robust(self):
        try:
            try:
                breadcrumb_div = self.browser.driver.find_element(By.XPATH,
                    "//div[contains(@data-bltgg, 'breadCrumb')]")
                if breadcrumb_div:
                    links = breadcrumb_div.find_elements(By.TAG_NAME, "a")
                    category_parts = []
                    
                    for link in links:
                        aria_label = link.get_attribute('aria-label')
                        if aria_label == 'Home':
                            continue
                        
                        text = link.text.strip()
                        if text and len(text) > 1:
                            category_parts.append(text)
                    
                    if category_parts:
                        return ' > '.join(category_parts)
            except:
                pass
            
            try:
                breadcrumb_div = self.browser.driver.find_element(By.CSS_SELECTOR,
                    'div[data-bltgg*="breadCrumb"]')
                if breadcrumb_div:
                    links = breadcrumb_div.find_elements(By.CSS_SELECTOR, 'a[href^="/nl/nl/l/"]')
                    category_parts = []
                    
                    for link in links:
                        text = link.text.strip()
                        if text and len(text) > 1:
                            category_parts.append(text)
                    
                    if category_parts:
                        return ' > '.join(category_parts)
            except:
                pass
            
            try:
                js_result = self.browser.driver.execute_script("""
                    var breadcrumbDiv = document.querySelector('div[data-bltgg*="breadCrumb"]');
                    if (!breadcrumbDiv) return null;
                    
                    var links = breadcrumbDiv.querySelectorAll('a');
                    var categories = [];
                    
                    for (var i = 0; i < links.length; i++) {
                        var link = links[i];
                        if (link.getAttribute('aria-label') === 'Home') continue;
                        
                        var text = link.innerText.trim();
                        if (text && text.length > 1) {
                            categories.push(text);
                        }
                    }
                    
                    return categories.length ? categories.join(' > ') : null;
                """)
                if js_result:
                    return js_result
            except:
                pass
            
            try:
                breadcrumb = self.browser.driver.find_element(By.XPATH,
                    "//nav[@aria-label='breadcrumb'] | //ol[contains(@class, 'breadcrumb')]")
                if breadcrumb:
                    items = breadcrumb.find_elements(By.TAG_NAME, "li")
                    category_parts = []
                    for item in items:
                        text = item.text.strip()
                        if text and text not in ['Home', '>'] and len(text) > 1:
                            category_parts.append(text)
                    if category_parts:
                        return ' > '.join(category_parts)
            except:
                pass
            
            return None
            
        except Exception as e:
            logger.debug(f"Error extracting category: {e}")
            return None
    
    def _extract_sponsor_robust(self):
        try:
            sponsor_keywords = ['gesponsord', 'sponsor', 'advertentie', 'aanbevolen', 
                              'aanbeveling', 'promoted', 'sponsored', 'preferred']
            
            try:
                elems = self.browser.driver.find_elements(By.XPATH,
                    "//span[contains(@class, 'text-')][contains(text(), 'Gesponsord') or contains(text(), 'Advertentie') or contains(text(), 'Aanbevolen')]")
                if elems:
                    return elems[0].text.strip()
            except:
                pass
            
            try:
                js_result = self.browser.driver.execute_script("""
                    var keywords = ['gesponsord', 'sponsor', 'advertentie', 'aanbevolen', 'aanbeveling'];
                    var spans = document.querySelectorAll('span, div, p');
                    for (var i = 0; i < spans.length; i++) {
                        var text = spans[i].innerText.toLowerCase().trim();
                        for (var j = 0; j < keywords.length; j++) {
                            if (text === keywords[j] || text.includes(keywords[j])) {
                                return spans[i].innerText.trim();
                            }
                        }
                    }
                    return null;
                """)
                if js_result:
                    return js_result
            except:
                pass
            
            try:
                title_area = self.browser.driver.find_element(By.XPATH,
                    "//*[@id='mainContent']/div/div[4]/div[2]")
                if title_area:
                    text = title_area.text.lower()
                    for keyword in sponsor_keywords:
                        if keyword in text:
                            lines = title_area.text.split('\n')
                            for line in lines:
                                if keyword in line.lower():
                                    return line.strip()
            except:
                pass
            
            return None
            
        except Exception as e:
            logger.debug(f"Error extracting sponsor: {e}")
            return None
    
    def _extract_seller_rating_robust(self):
        try:
            try:
                seller_span = self.browser.driver.find_element(By.XPATH,
                    '//*[@id="buyBlockSlot"]/span')
                if seller_span:
                    full_text = seller_span.text.strip()
                    if full_text and len(full_text) > 5:
                        cleaned_text = ' '.join(full_text.split())
                        return cleaned_text[:500]
            except Exception as e:
                logger.debug(f"XPath buyBlockSlot/span failed: {e}")
                pass

            try:
                seller_span = self.browser.driver.find_element(By.XPATH,
                    '//*[@id="buyBlockSlot"]//span[contains(@class, "typography-body-default-200") and contains(@class, "flex-wrap")]')
                if seller_span:
                    full_text = seller_span.text.strip()
                    if full_text and len(full_text) > 5:
                        cleaned_text = ' '.join(full_text.split())
                        return cleaned_text[:500]
            except:
                pass

            try:
                buy_block = self.browser.driver.find_element(By.ID, "buyBlockSlot")
                if buy_block:
                    seller_info_span = buy_block.find_element(By.XPATH, 
                        ".//span[contains(@class, 'typography-body-default-200') and contains(@class, 'flex-wrap')]")

                    verkoop_door = ""
                    try:
                        verkoop_elem = seller_info_span.find_element(By.XPATH, ".//span[contains(text(), 'Verkoop door')]")
                        verkoop_door = verkoop_elem.text.strip()
                    except:
                        pass

                    seller_name = ""
                    try:
                        seller_button = seller_info_span.find_element(By.XPATH, 
                            ".//button[.//span[contains(@aria-label, 'Verkoop door')]]")
                        aria_label = seller_button.get_attribute('aria-label')
                        if aria_label:
                            seller_name = aria_label.replace('Verkoop door', '').strip()
                        else:
                            name_span = seller_button.find_element(By.XPATH, ".//span[contains(@class, 'underline')]")
                            seller_name = name_span.text.strip()
                    except:
                        pass

                    rating = ""
                    try:
                        rating_div = seller_info_span.find_element(By.XPATH, 
                            ".//div[contains(@class, 'bg-brand-background-interactive-default')]")
                        rating = rating_div.text.strip()
                    except:
                        pass

                    parts = []
                    if verkoop_door:
                        parts.append(verkoop_door)
                    if seller_name:
                        parts.append(seller_name)
                    if rating:
                        parts.append(f"Rating: {rating}")

                    if parts:
                        return ' '.join(parts)[:500]
            except Exception as e:
                logger.debug(f"Component extraction failed: {e}")
                pass

            try:
                js_result = self.browser.driver.execute_script("""
                    var buyBlock = document.getElementById('buyBlockSlot');
                    if (!buyBlock) return null;

                    var span = buyBlock.querySelector('span.typography-body-default-200.flex.flex-wrap.wrap-break-word');
                    if (!span) return null;

                    var result = [];

                    var verkoopDoor = span.querySelector('span[aria-hidden="true"]');
                    if (verkoopDoor) result.push(verkoopDoor.innerText.trim());

                    var sellerButton = span.querySelector('button[data-bltgh*="OpenRetailerDialog"]');
                    if (sellerButton) {
                        var ariaLabel = sellerButton.getAttribute('aria-label');
                        if (ariaLabel) {
                            result.push(ariaLabel.replace('Verkoop door', '').trim());
                        } else {
                            var sellerSpan = sellerButton.querySelector('span.underline');
                            if (sellerSpan) result.push(sellerSpan.innerText.trim());
                        }
                    }

                    var ratingDiv = span.querySelector('div.bg-brand-background-interactive-default');
                    if (ratingDiv) result.push('Rating: ' + ratingDiv.innerText.trim());

                    return result.join(' ');
                """)
                if js_result:
                    return js_result[:500]
            except:
                pass

            try:
                seller_span = self.browser.driver.find_element(By.CSS_SELECTOR,
                    '#buyBlockSlot > span.typography-body-default-200')
                if seller_span:
                    full_text = seller_span.text.strip()
                    if full_text and len(full_text) > 5:
                        cleaned_text = ' '.join(full_text.split())
                        return cleaned_text[:500]
            except:
                pass

            try:
                buy_block = self.browser.driver.find_element(By.ID, "buyBlockSlot")
                elems = buy_block.find_elements(By.XPATH,
                    ".//*[contains(text(), 'Verkoop door')]")
                if elems:
                    for elem in elems:
                        parent = elem.find_element(By.XPATH, "..")
                        if parent:
                            text = parent.text.strip()
                            if len(text) > 10:
                                return text[:500]
            except:
                pass

            return None

        except Exception as e:
            logger.debug(f"Error extracting seller rating: {e}")
            return None
    
    def _extract_specification(self):
        try:
            try:
                spec_div = self.browser.driver.find_element(By.XPATH,
                    '//div[@data-testid="collapsible-content"]')
                if spec_div:
                    full_text = spec_div.text.strip()
                    if full_text and len(full_text) > 20:
                        lines = [line.strip() for line in full_text.split('\n') if line.strip()]
                        cleaned_text = '\n'.join(lines)
                        return cleaned_text[:8000]
            except Exception as e:
                logger.debug(f"Strategy 1 failed: {e}")
                pass

            try:
                spec_heading = self.browser.driver.find_element(By.XPATH,
                    "//h2[contains(text(), 'Product specifications') or contains(text(), 'Products specificaties')]")
                if spec_heading:
                    parent = spec_heading.find_element(By.XPATH, "ancestor::div[@data-testid='collapsible-content']")
                    if parent:
                        full_text = parent.text.strip()
                        if full_text:
                            lines = [line.strip() for line in full_text.split('\n') if line.strip()]
                            return '\n'.join(lines)[:8000]
            except:
                pass

            try:
                js_result = self.browser.driver.execute_script("""
                    var specHeading = Array.from(document.querySelectorAll('h2')).find(h => 
                        h.textContent.includes('Product specifications') || 
                        h.textContent.includes('Productspecificaties') ||
                        h.textContent.includes('Specificaties')
                    );

                    if (specHeading) {
                        specHeading.scrollIntoView({behavior: 'instant', block: 'center'});

                        var container = specHeading.closest('[data-testid="collapsible-content"]');
                        if (!container) {
                            var parent = specHeading.parentElement;
                            for (var i = 0; i < 5; i++) {
                                if (parent && parent.getAttribute('data-testid') === 'collapsible-content') {
                                    container = parent;
                                    break;
                                }
                                parent = parent ? parent.parentElement : null;
                            }
                        }

                        if (container) {
                            var text = container.innerText || container.textContent;
                            return text.trim();
                        }
                    }

                    var div = document.querySelector('div[data-testid="collapsible-content"]');
                    if (div) return div.innerText.trim();

                    return null;
                """)
                if js_result and len(js_result) > 20:
                    lines = [line.strip() for line in js_result.split('\n') if line.strip()]
                    return '\n'.join(lines)[:8000]
            except Exception as e:
                logger.debug(f"JavaScript extraction failed: {e}")
                pass

            try:
                spec_tables = self.browser.driver.find_elements(By.XPATH,
                    "//div[@data-testid='data_table']")
                if spec_tables:
                    all_specs = []
                    for table in spec_tables:
                        try:
                            heading = table.find_element(By.XPATH, " preceding-sibling::h3[1]")
                            if heading:
                                all_specs.append(heading.text.strip())
                        except:
                            pass

                        rows = table.find_elements(By.XPATH, ".//div[contains(@class, 'flex py-2')]")
                        for row in rows:
                            try:
                                label = row.find_element(By.XPATH, ".//div[contains(@class, 'w-1/2')][1]").text.strip()
                                value = row.find_element(By.XPATH, ".//div[contains(@class, 'w-1/2')][2]").text.strip()
                                if label and value:
                                    all_specs.append(f"{label}: {value}")
                            except:
                                pass

                    if all_specs:
                        return '\n'.join(all_specs)[:8000]
            except:
                pass

            try:
                expand_buttons = self.browser.driver.find_elements(By.XPATH,
                    "//button[contains(text(), 'Show more') or contains(text(), 'Toon meer') or contains(@aria-label, 'expand')]")
                for btn in expand_buttons:
                    try:
                        self.browser.driver.execute_script("arguments[0].click();", btn)
                        time.sleep(1)
                    except:
                        pass

                spec_div = self.browser.driver.find_element(By.XPATH,
                    '//div[@data-testid="collapsible-content"]')
                if spec_div:
                    full_text = spec_div.text.strip()
                    if full_text:
                        lines = [line.strip() for line in full_text.split('\n') if line.strip()]
                        return '\n'.join(lines)[:8000]
            except:
                pass

            return None

        except Exception as e:
            logger.debug(f"Error extracting specification: {e}")
            return None
                        
    def _extract_price_ultra_robust(self):
        price = 0.0
        
        try:
            elem = self.browser.driver.find_element(By.XPATH, self.xpaths['price'])
            text = elem.text.strip()
            price = self._parse_price_text(text)
            if price > 0:
                return price
        except:
            pass
        
        try:
            elem = self.browser.driver.find_element(By.XPATH, "//span[@class='row-span-2' and @aria-hidden='true']")
            text = elem.text.strip()
            price = self._parse_price_text(text)
            if price > 0:
                return price
        except:
            pass
        
        try:
            parent = self.browser.driver.find_element(By.XPATH, "//*[@id='buyBlockSlot']")
            full_text = parent.text
            price = self._extract_price_from_text(full_text)
            if price > 0:
                return price
        except:
            pass
        
        try:
            meta = self.browser.driver.find_element(By.CSS_SELECTOR, 'meta[property="product:price:amount"]')
            content = meta.get_attribute('content')
            if content:
                return float(content)
        except:
            pass
        
        return price
    
    def _parse_price_text(self, text):
        if not text:
            return 0.0
        
        try:
            text = text.replace('€', '').strip()
            text = text.replace('–', '').replace('-', '').strip()
            
            if '.' in text and ',' in text:
                text = text.replace('.', '').replace(',', '.')
            elif ',' in text and text.count(',') == 1:
                parts = text.split(',')
                if len(parts) == 2 and len(parts[1]) <= 2:
                    text = text.replace(',', '.')
                else:
                    text = text.replace(',', '')
            elif '.' in text:
                parts = text.split('.')
                if len(parts) == 2 and len(parts[1]) <= 2:
                    text = text.replace('.', '')
                elif len(parts[1]) == 3:
                    text = text.replace('.', '')
            
            match = re.search(r'(\d+(?:\.\d{1,2})?)', text)
            if match:
                num_str = match.group(1)
                if '.' in num_str:
                    return float(num_str)
                else:
                    return float(num_str)
        except:
            pass
        
        return 0.0
    
    def _extract_price_from_text(self, text):
        if not text:
            return 0.0
        
        try:
            lines = text.split('\n')
            for line in lines:
                line = line.strip()
                if len(line) < 2 or len(line) > 20:
                    continue
                
                if any(char.isdigit() for char in line):
                    price = self._parse_price_text(line)
                    if price > 100 and price < 10000:
                        return price
            
            patterns = [
                r'(\d{1,3}(?:\.\d{3})+)(?:,00)?',
                r'(\d{1,3}(?:,\d{3})+)(?:\.00)?',
                r'(\d+)[,\.](\d{2})',
                r'\b(\d{3,4})\b',
            ]
            
            for pattern in patterns:
                matches = re.findall(pattern, text)
                for match in matches:
                    if isinstance(match, tuple):
                        match_str = ''.join(match)
                    else:
                        match_str = str(match)
                    
                    price = self._parse_price_text(match_str)
                    if price > 100:
                        return price
        except:
            pass
        
        return 0.0
    
    def _clean_availability(self, text):
        if not text:
            return "Unknown"
        
        text = text.replace('\n', ' ').replace('\r', ' ')
        text = text.replace('Select', '').strip()
        text = ' '.join(text.split())
        
        if len(text) > 100:
            sentences = text.split('.')
            if len(sentences[0]) < 100:
                return sentences[0].strip()
        
        return text.strip()
    
    def _extract_brand_simple(self):
        try:
            text = self._get_text_by_xpath(self.xpaths['seller_brand'])
            if text:
                text = text.replace('Merk:', '').replace('Merk', '').strip()
                return text
        except:
            pass
        return "Bol.com"
    
    def _extract_rating_simple(self):
        try:
            elem = self.browser.driver.find_element(By.XPATH, self.xpaths['rating_button'])
            if elem:
                text = elem.text.strip()
                match = re.search(r'(\d+[,.]\d*)', text)
                if match:
                    return float(match.group(1).replace(',', '.'))
        except:
            pass
        
        try:
            header = self.browser.driver.find_element(By.XPATH, '//*[@id="mainContent"]/div/div[4]/div[2]/div/div[2]')
            if header:
                text = header.text
                match = re.search(r'(\d+[,.]\d*)', text)
                if match:
                    return float(match.group(1).replace(',', '.'))
        except:
            pass
        
        return 0.0
    
    def _extract_review_count_simple(self):
        try:
            elem = self.browser.driver.find_element(By.XPATH, self.xpaths['rating_button'])
            if elem:
                text = elem.text.strip()
                match = re.search(r'Bekijk\s+(\d+)\s+review', text, re.IGNORECASE)
                if match:
                    return int(match.group(1))
        except:
            pass
        
        try:
            header = self.browser.driver.find_element(By.XPATH, '//*[@id="mainContent"]/div/div[4]/div[2]/div/div[2]')
            if header:
                text = header.text
                match = re.search(r'(\d+)\s+review', text, re.IGNORECASE)
                if match:
                    return int(match.group(1))
        except:
            pass
        
        return 0
    
    def _extract_image_simple(self):
        try:
            meta = self.browser.driver.find_element(By.CSS_SELECTOR, 'meta[property="og:image"]')
            if meta:
                return meta.get_attribute('content')
        except:
            pass
        
        try:
            img = self.browser.driver.find_element(By.CSS_SELECTOR, 'img[src*="media.s-bol.com"]')
            if img:
                return img.get_attribute('src')
        except:
            pass
        
        return None
    
    def _extract_review_text(self):
        reviews = []

        try:
            logger.info("Extracting review text...")
            wait = WebDriverWait(self.browser.driver, 10)

            # === STEP 1: Scroll to reviews section (improved from old code) ===
            try:
                review_headings = self.browser.driver.find_elements(By.XPATH,
                    "//h2[contains(text(), 'review') or contains(text(), 'Review') or contains(@data-testid, 'review')]")

                if review_headings:
                    self.browser.driver.execute_script(
                        "arguments[0].scrollIntoView({block: 'center'});", 
                        review_headings[0]
                    )
                    logger.debug("Scrolled to reviews section")
                    time.sleep(5)
            except Exception as e:
                logger.debug(f"Could not scroll to reviews heading: {e}")

            # === STEP 2: Click "Load More" button multiple times (from new code) ===
            max_clicks = 15  # Increased from 10 to get more reviews
            for i in range(max_clicks):
                try:
                    # Scroll down to load more content
                    self.browser.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    time.sleep(5)

                    # Find button by CSS selector
                    load_more_btn = self.browser.driver.find_element(
                        By.CSS_SELECTOR,
                        "button.mt-6"
                    )

                    # Scroll to button and click
                    self.browser.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", load_more_btn)
                    time.sleep(5)
                    self.browser.driver.execute_script("arguments[0].click();", load_more_btn)
                    logger.info(f"Clicked 'Load More' button ({i+1})")

                    # Wait for new content to load
                    time.sleep(8)

                except NoSuchElementException:
                    logger.info("No more 'Load More' button found. Proceeding to extraction.")
                    break
                except Exception as e:
                    logger.debug(f"Error clicking button: {e}")
                    break

            # === STEP 3: Extract reviews using BeautifulSoup + Selenium (merged approach) ===
            # First, try BeautifulSoup on the full page source
            soup = BeautifulSoup(self.browser.driver.page_source, 'html.parser')

            # Try multiple strategies to find reviews
            review_items = []

            # Strategy 1: Look for li with class 'review-item'
            review_items = soup.find_all('li', class_='review-item')

            # Strategy 2: If not found, look for div with data-testid='review-details'
            if not review_items:
                review_items = soup.find_all('div', {'data-testid': 'review-details'})

            # Strategy 3: Look for any div containing 'review' in class or data-testid
            if not review_items:
                review_items = soup.find_all(['div', 'li'], attrs={
                    'class': lambda x: x and 'review' in x,
                    'data-testid': lambda x: x and 'review' in x
                })

            if review_items:
                logger.info(f"Found {len(review_items)} reviews via BeautifulSoup")

                for idx, item in enumerate(review_items):
                    try:
                        review_data = {}

                        # Extract text - look for p tag first, then any text
                        text_elem = item.find('p')
                        if text_elem:
                            text = text_elem.get_text(strip=True)
                        else:
                            # Try to find the longest text in the item
                            texts = [t.get_text(strip=True) for t in item.find_all(text=True)]
                            text = max(texts, key=len) if texts else ''

                        if not text or len(text) <= 5:
                            continue

                        review_data['text'] = text

                        # Extract reviewer name
                        try:
                            # Look for meta info div
                            meta_elem = item.find('div', class_=lambda x: x and 'text-neutral-text-medium' in x)
                            if meta_elem:
                                meta_text = meta_elem.get_text(strip=True)
                                parts = meta_text.split('•')
                                review_data['reviewer'] = parts[-1].strip() if len(parts) > 1 else meta_text
                                review_data['meta'] = meta_text
                            else:
                                review_data['reviewer'] = 'Unknown'
                                review_data['meta'] = ''
                        except:
                            review_data['reviewer'] = 'Unknown'
                            review_data['meta'] = ''

                        # Extract rating
                        try:
                            rating_elem = item.find('div', {'role': 'img', 'aria-label': lambda x: x and 'sterren' in x})
                            review_data['rating'] = rating_elem.get('aria-label', '') if rating_elem else ''
                        except:
                            review_data['rating'] = ''

                        # Extract title
                        try:
                            title_elem = item.find('span', class_=lambda x: x and 'typography-body-maximal-200' in x)
                            review_data['title'] = title_elem.get_text(strip=True) if title_elem else ''
                        except:
                            review_data['title'] = ''

                        # Extract pros (look for bg-accent3 class)
                        try:
                            pros = []
                            pro_icons = item.find_all('div', class_=lambda x: x and 'bg-accent3' in x)
                            for icon in pro_icons:
                                try:
                                    # Look for sibling span or parent text
                                    text_elem = icon.find_next_sibling('span')
                                    if text_elem:
                                        pros.append(text_elem.get_text(strip=True))
                                except:
                                    pass
                            review_data['pros'] = pros
                        except:
                            review_data['pros'] = []

                        # Extract cons (look for bg-accent2 class)
                        try:
                            cons = []
                            con_icons = item.find_all('div', class_=lambda x: x and 'bg-accent2' in x)
                            for icon in con_icons:
                                try:
                                    text_elem = icon.find_next_sibling('span')
                                    if text_elem:
                                        cons.append(text_elem.get_text(strip=True))
                                except:
                                    pass
                            review_data['cons'] = cons
                        except:
                            review_data['cons'] = []

                        # Extract likes/dislikes
                        try:
                            like_btn = item.find('button', {'aria-label': lambda x: x and '👍' in x})
                            if like_btn:
                                like_div = like_btn.find('div', class_=lambda x: x and 'text-neutral-text-high' in x)
                                review_data['likes'] = like_div.get_text(strip=True) if like_div else '0'
                            else:
                                review_data['likes'] = '0'
                        except:
                            review_data['likes'] = '0'

                        try:
                            dislike_btn = item.find('button', {'aria-label': lambda x: x and '👎' in x})
                            if dislike_btn:
                                dislike_div = dislike_btn.find('div', class_=lambda x: x and 'text-neutral-text-high' in x)
                                review_data['dislikes'] = dislike_div.get_text(strip=True) if dislike_div else '0'
                            else:
                                review_data['dislikes'] = '0'
                        except:
                            review_data['dislikes'] = '0'

                        # Format the review
                        formatted_review = (
                            f"Review #{idx+1}:\n"
                            f"Reviewer: {review_data.get('reviewer', 'Unknown')}\n"
                            f"Rating: {review_data.get('rating', '')}\n"
                            f"Title: {review_data.get('title', '')}\n"
                            f"Info: {review_data.get('meta', '')}\n"
                            f"Text: {review_data.get('text', '')}\n"
                            f"Pros: {', '.join(review_data.get('pros', [])) if review_data.get('pros') else 'None'}\n"
                            f"Cons: {', '.join(review_data.get('cons', [])) if review_data.get('cons') else 'None'}\n"
                            f"Helpful: 👍 {review_data.get('likes', '0')}  👎 {review_data.get('dislikes', '0')}\n"
                            f"---"
                        )

                        reviews.append(formatted_review)

                    except Exception as e:
                        logger.debug(f"Error processing review {idx}: {e}")
                        continue

            # === STEP 4: Fallback to Selenium if BeautifulSoup found nothing ===
            if not reviews:
                logger.info("BeautifulSoup found no reviews, trying Selenium fallback...")

                review_containers = []

                try:
                    review_containers = self.browser.driver.find_elements(By.XPATH,
                        '//div[@data-testid="review-details"]')
                except:
                    pass

                if not review_containers:
                    try:
                        review_containers = self.browser.driver.find_elements(By.CSS_SELECTOR,
                            '[class*="review"], [data-testid*="review"]')
                    except:
                        pass

                if review_containers:
                    logger.info(f"Found {len(review_containers)} reviews via Selenium")
                    for idx, review in enumerate(review_containers):
                        try:
                            review_data = {}

                            try:
                                meta_elem = review.find_element(By.XPATH, 
                                    './/div[contains(@class, "text-neutral-text-medium")]')
                                meta_text = meta_elem.text
                                parts = meta_text.split('•')
                                review_data['reviewer'] = parts[-1].strip() if parts else 'Unknown'
                            except:
                                review_data['reviewer'] = 'Unknown'

                            try:
                                rating_elem = review.find_element(By.XPATH,
                                    './/div[@role="img" and contains(@aria-label, "sterren")]')
                                review_data['rating'] = rating_elem.get_attribute('aria-label')
                            except:
                                review_data['rating'] = ''

                            try:
                                title_elem = review.find_element(By.XPATH,
                                    './/span[contains(@class, "typography-body-maximal-200")]')
                                review_data['title'] = title_elem.text
                            except:
                                review_data['title'] = ''

                            try:
                                review_data['meta'] = meta_text if 'meta_text' in locals() else ''
                            except:
                                review_data['meta'] = ''

                            try:
                                paragraphs = review.find_elements(By.TAG_NAME, 'p')
                                longest = ''
                                for p in paragraphs:
                                    text = p.text.strip()
                                    if len(text) > len(longest):
                                        longest = text
                                review_data['text'] = longest
                            except:
                                review_data['text'] = ''

                            try:
                                pros = []
                                pro_icons = review.find_elements(By.XPATH,
                                    './/div[contains(@class, "bg-accent3")]')
                                for icon in pro_icons:
                                    try:
                                        text_elem = icon.find_element(By.XPATH, 'following-sibling::span[1]')
                                        if text_elem.text:
                                            pros.append(text_elem.text)
                                    except:
                                        pass
                                review_data['pros'] = pros
                            except:
                                review_data['pros'] = []

                            try:
                                cons = []
                                con_icons = review.find_elements(By.XPATH,
                                    './/div[contains(@class, "bg-accent2")]')
                                for icon in con_icons:
                                    try:
                                        text_elem = icon.find_element(By.XPATH, 'following-sibling::span[1]')
                                        if text_elem.text:
                                            cons.append(text_elem.text)
                                    except:
                                        pass
                                review_data['cons'] = cons
                            except:
                                review_data['cons'] = []

                            try:
                                like_elem = review.find_element(By.XPATH,
                                    './/button[contains(@aria-label, "👍")]//div[contains(@class, "text-neutral-text-high")]')
                                review_data['likes'] = like_elem.text
                            except:
                                review_data['likes'] = '0'

                            try:
                                dislike_elem = review.find_element(By.XPATH,
                                    './/button[contains(@aria-label, "👎")]//div[contains(@class, "text-neutral-text-high")]')
                                review_data['dislikes'] = dislike_elem.text
                            except:
                                review_data['dislikes'] = '0'

                            formatted_review = (
                                f"Review #{idx+1}:\n"
                                f"Reviewer: {review_data.get('reviewer', 'Unknown')}\n"
                                f"Rating: {review_data.get('rating', '')}\n"
                                f"Title: {review_data.get('title', '')}\n"
                                f"Info: {review_data.get('meta', '')}\n"
                                f"Text: {review_data.get('text', '')}\n"
                                f"Pros: {', '.join(review_data.get('pros', [])) if review_data.get('pros') else 'None'}\n"
                                f"Cons: {', '.join(review_data.get('cons', [])) if review_data.get('cons') else 'None'}\n"
                                f"Helpful: 👍 {review_data.get('likes', '0')}  👎 {review_data.get('dislikes', '0')}\n"
                                f"---"
                            )

                            reviews.append(formatted_review)

                        except Exception as e:
                            logger.debug(f"Error processing review {idx}: {e}")
                            continue

            # === STEP 5: Final text-only fallback ===
            if not reviews:
                logger.debug("All structured extraction failed, using text fallback")
                try:
                    review_elements = self.browser.driver.find_elements(By.XPATH,
                        "//div[contains(@data-testid, 'review')]//p | //div[contains(@class, 'review')]//p")
                    for elem in review_elements:
                        text = elem.text.strip()
                        if text:
                            reviews.append(text)
                except:
                    pass

                if not reviews:
                    try:
                        review_elements = self.browser.driver.find_elements(By.CSS_SELECTOR,
                            ".review-text, .review-content, [class*='review__text']")
                        for elem in review_elements:
                            text = elem.text.strip()
                            if text:
                                reviews.append(text)
                    except:
                        pass

                if reviews:
                    return " ||| ".join(reviews)

            if reviews:
                return "\n\n".join(reviews)
            else:
                return "No reviews found"

        except Exception as e:
            logger.error(f"Error extracting reviews: {e}")
            return None

    def _extract_description(self):
        try:
            try:
                elem = self.browser.driver.find_element(By.XPATH, 
                    '//*[@id="mainContent"]/div/div[4]/div[3]/section[4]')
                if elem:
                    text = elem.text.strip()
                    if len(text) > 20:
                        return text[:5000]
            except:
                pass
            
            try:
                js_result = self.browser.driver.execute_script("""
                    var elem = document.querySelector("#mainContent > div > div.grid.grid-cols-2.gap-x-10.auto-rows-min.items-start > div:nth-child(3) > section:nth-child(7) > div > div > div > div > div.pr-10.prose");
                    return elem ? elem.innerText.trim() : null;
                """)
                if js_result and len(js_result) > 20:
                    return js_result[:5000]
            except:
                pass
            
            return None
            
        except Exception as e:
            logger.debug(f"Error extracting description: {e}")
            return None