import sqlite3
import logging
import os
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)


class SimpleDatabase:
    def __init__(self, db_file="bol_data.db"):
        self.db_file = db_file
        self.init_database()
    
    def init_database(self):
        """Initialize database with all tables and columns"""
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        
        # Create products table with ALL 18 columns
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id TEXT PRIMARY KEY,
                url TEXT,
                title TEXT,
                price REAL,
                currency TEXT,
                availability TEXT,
                seller_brand TEXT,
                rating REAL,
                review_count INTEGER,
                review_text TEXT,
                category TEXT,
                image_url TEXT,
                search_term TEXT,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                sponsor_preference TEXT,
                description_specification TEXT,
                seller_and_rating TEXT,
                specification TEXT
            )
        ''')
        
        # If table already exists, check and add missing columns
        self._ensure_columns_exist(cursor)
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scraper_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                items_scraped INTEGER DEFAULT 0,
                status TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
        logger.info(f"Database ready: {self.db_file}")
    
    def _ensure_columns_exist(self, cursor):
        """Check existing columns and add missing ones"""
        try:
            cursor.execute("PRAGMA table_info(products)")
            existing_columns = [row[1] for row in cursor.fetchall()]
            
            required_columns = {
                'sponsor_preference': 'TEXT',
                'description_specification': 'TEXT',
                'seller_and_rating': 'TEXT',
                'specification': 'TEXT'
            }
            
            for col_name, col_type in required_columns.items():
                if col_name not in existing_columns:
                    try:
                        cursor.execute(f"ALTER TABLE products ADD COLUMN {col_name} {col_type}")
                        logger.info(f"Added missing column: {col_name}")
                    except Exception as e:
                        logger.error(f"Error adding column {col_name}: {e}")
                        
        except Exception as e:
            logger.error(f"Error checking columns: {e}")
    
    # ADDED: New method to check if product already exists
    def product_exists(self, product_id):
        """Check if product ID already exists in database"""
        try:
            conn = sqlite3.connect(self.db_file)
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM products WHERE id = ?", (product_id,))
            exists = cursor.fetchone() is not None
            conn.close()
            return exists
        except Exception as e:
            logger.error(f"Error checking product existence: {e}")
            return False
    
    # ADDED: New method to get existing product data
    def get_existing_product(self, product_id):
        """Get existing product data by ID"""
        try:
            conn = sqlite3.connect(self.db_file)
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM products WHERE id = ?", (product_id,))
            row = cursor.fetchone()
            conn.close()
            return row
        except Exception as e:
            logger.error(f"Error fetching existing product: {e}")
            return None
    
    def save_product(self, product_data):
        try:
            conn = sqlite3.connect(self.db_file)
            cursor = conn.cursor()
            
            rating = product_data.get('rating')
            if rating:
                try:
                    rating = float(rating)
                except:
                    rating = 0.0
            
            review_count = product_data.get('review_count')
            if review_count:
                try:
                    review_count = int(review_count)
                except:
                    review_count = 0
            
            cursor.execute('''
                INSERT OR REPLACE INTO products 
                (id, url, title, price, currency, availability, seller_brand, 
                rating, review_count, review_text, category, image_url, search_term, scraped_at,
                sponsor_preference, description_specification, seller_and_rating, specification)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                product_data.get('id'),
                product_data.get('url'),
                product_data.get('title'),
                product_data.get('price'),
                product_data.get('currency', 'EUR'),
                product_data.get('availability'),
                product_data.get('seller_brand'),
                rating,
                review_count,
                product_data.get('review_text'),
                product_data.get('category'),
                product_data.get('image_url'),
                product_data.get('search_term'),
                datetime.now(),
                product_data.get('sponsor_preference'),
                product_data.get('description_specification'),
                product_data.get('seller_and_rating'),
                product_data.get('specification')
            ))
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            logger.error(f"Error saving product: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False
    
    def log_run_start(self):
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO scraper_runs (status) VALUES ('running')")
        run_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return run_id
    
    def log_run_end(self, run_id, items_count, status='completed'):
        conn = sqlite3.connect(self.db_file)
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE scraper_runs 
            SET items_scraped = ?, status = ? 
            WHERE id = ?
        ''', (items_count, status, run_id))
        conn.commit()
        conn.close()

    def get_stats(self):
        try:
            conn = sqlite3.connect(self.db_file)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM products")
            count = cursor.fetchone()[0]
            conn.close()
            return count
        except:
            return 0
    
    def reset_database(self):
        try:
            if os.path.exists(self.db_file):
                os.remove(self.db_file)
                logger.info(f"Deleted old database: {self.db_file}")
            self.init_database()
            return True
        except Exception as e:
            logger.error(f"Error resetting database: {e}")
            return False