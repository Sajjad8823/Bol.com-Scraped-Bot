import time
import random
import logging
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException

# Use selenium-wire instead of undetected-chromedriver for proxy auth
from seleniumwire import webdriver as wire_webdriver
from selenium.webdriver.chrome.options import Options

logger = logging.getLogger(__name__)

class SimpleBrowser:
    def __init__(self, headless=False, proxy=None):
        self.headless = headless
        self.proxy = proxy
        self.driver = None
    
    def start(self):
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                logger.info(f"Starting Chrome... Attempt {attempt + 1}/{max_attempts}")
                
                chrome_options = Options()
                
                if self.headless:
                    chrome_options.add_argument('--headless=new')
                
                # Standard stability args
                chrome_options.add_argument('--window-size=1920,1080')
                chrome_options.add_argument("--disable-blink-features=AutomationControlled")
                chrome_options.add_argument("--no-first-run")
                chrome_options.add_argument("--no-default-browser-check")
                chrome_options.add_argument("--disable-dev-shm-usage")
                chrome_options.add_argument("--disable-gpu")
                
                # Selenium-wire options for proxy
                seleniumwire_options = None
                if self.proxy:
                    # Parse proxy
                    import re
                    pattern = r'http://([^:]+):([^@]+)@([^:]+):(\d+)'
                    match = re.match(pattern, self.proxy)
                    
                    if match:
                        username, password, host, port = match.groups()
                        proxy_display = f"{host}:{port}"
                        logger.info(f"Using authenticated proxy: {proxy_display}")
                        
                        seleniumwire_options = {
                            'proxy': {
                                'http': f'http://{username}:{password}@{host}:{port}',
                                'https': f'http://{username}:{password}@{host}:{port}',
                            }
                        }
                    else:
                        logger.info(f"Using proxy: {self.proxy}")
                        seleniumwire_options = {
                            'proxy': {
                                'http': self.proxy,
                                'https': self.proxy,
                            }
                        }
                
                # Start browser with selenium-wire
                self.driver = wire_webdriver.Chrome(
                    options=chrome_options,
                    seleniumwire_options=seleniumwire_options
                )
                
                time.sleep(3)
                
                # Verify browser
                handles = self.driver.window_handles
                if len(handles) == 0:
                    raise WebDriverException("Browser has no windows")
                
                logger.info(f"Browser active with handle: {handles[0]}")
                logger.info("Chrome started successfully!")
                return self.driver
                
            except Exception as e:
                logger.error(f"Attempt {attempt + 1} failed: {e}")
                if self.driver:
                    try:
                        self.driver.quit()
                    except:
                        pass
                    self.driver = None
                
                if attempt < max_attempts - 1:
                    logger.info("Waiting 5 seconds before retry...")
                    time.sleep(5)
                else:
                    logger.error("All attempts to start Chrome failed")
                    raise
    
    def open_page(self, url):
        try:
            try:
                _ = self.driver.current_url
            except:
                logger.error("Browser window closed unexpectedly!")
                return False
            
            logger.info(f"Opening: {url}")
            self.driver.get(url)
            
            time.sleep(5)
            
            # Check for proxy errors
            page_source = self.driver.page_source
            if any(err in page_source for err in ["ERR_PROXY_CONNECTION_FAILED", 
                                                   "This site can't be reached"]):
                logger.error(f"Proxy connection failed for {url}")
                return False
            
            title = self.driver.title
            if title:
                logger.info(f"Page loaded: {title[:50]}...")
                return True
                
            return False
                
        except Exception as e:
            logger.error(f"Error opening page: {e}")
            return False
    
    def find_by_xpath(self, xpath, timeout=10):
        try:
            _ = self.driver.current_url
            wait = WebDriverWait(self.driver, timeout)
            element = wait.until(
                EC.presence_of_element_located((By.XPATH, xpath))
            )
            return element
        except (TimeoutException, WebDriverException):
            return None
        except Exception:
            return None
    
    def find_elements(self, css_selector, timeout=10):
        try:
            _ = self.driver.current_url
            wait = WebDriverWait(self.driver, timeout)
            elements = wait.until(
                EC.presence_of_all_elements_located((By.CSS_SELECTOR, css_selector))
            )
            return elements
        except (TimeoutException, WebDriverException):
            return []
        except Exception:
            return []
    
    def scroll_down(self):
        try:
            scroll_amount = random.randint(300, 700)
            self.driver.execute_script(f"window.scrollBy(0, {scroll_amount});")
            time.sleep(random.uniform(1, 3))
        except Exception as e:
            logger.debug(f"Scroll failed: {e}")
    
    def save_screenshot(self, filename):
        try:
            import os
            if not os.path.exists('screenshots'):
                os.makedirs('screenshots')
            filepath = f"screenshots/{filename}"
            self.driver.save_screenshot(filepath)
            logger.info(f"Screenshot saved: {filepath}")
        except Exception as e:
            logger.error(f"Could not save screenshot: {e}")
    
    def close(self):
        if self.driver:
            try:
                self.driver.quit()
                logger.info("Browser closed")
            except:
                pass